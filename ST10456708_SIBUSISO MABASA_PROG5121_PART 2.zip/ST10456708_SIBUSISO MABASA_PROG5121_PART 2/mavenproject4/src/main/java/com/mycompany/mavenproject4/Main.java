package com.mycompany.mavenproject4;

import com.mycompany.mavenproject4.Login;

import javax.swing.*;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Message> sentMessages = new ArrayList<>();

        // Step 1: Login
        Login login = new Login("user_1", "Pass@123", "+27718693002", "John", "Doe");
        if (!login.loginUser("user_1", "Pass@123")) {
            System.out.println("Login failed.");
            return;
        }

        System.out.println(login.returnLoginStatus());
        System.out.println("Welcome to QuickChat.");

        // Step 2: Ask how many messages user wants to send
        System.out.print("How many messages would you like to enter? ");
        int maxMessages = scanner.nextInt();
        scanner.nextLine();

        int messageCount = 0;

        while (true) {
            System.out.println("\n1) Send Message\n2) Show Recently Sent Messages\n3) Quit");
            System.out.print("Choose an option: ");
            int option = scanner.nextInt();
            scanner.nextLine();

            switch (option) {
                case 1:
                    if (messageCount >= maxMessages) {
                        System.out.println("Message limit reached.");
                        break;
                    }

                    System.out.print("Enter recipient number (e.g. +27718693002): ");
                    String recipient = scanner.nextLine();

                    System.out.print("Enter message (max 250 chars): ");
                    String msgText = scanner.nextLine();

                    if (msgText.length() > 250) {
                        System.out.println("Message exceeds 250 characters by " + (msgText.length() - 250));
                        break;
                    }

                    Message msg = new Message(recipient, msgText);

                    if (!msg.checkRecipientCell()) {
                        System.out.println("Cell phone number is incorrectly formatted or does not contain an international code.");
                        break;
                    }

                    System.out.println("Choose action: send / discard / store");
                    String action = scanner.nextLine();

                    String result = msg.sendMessage(action);
                    if (action.equalsIgnoreCase("send")) {
                        sentMessages.add(msg);
                        messageCount++;
                    }

                    JOptionPane.showMessageDialog(null, msg.printMessageDetails());
                    System.out.println(result);
                    break;

                case 2:
                    System.out.println("Coming Soon.");
                    break;

                case 3:
                    System.out.println("Total messages sent: " + Message.returnTotalMessages());
                    return;

                default:
                    System.out.println("Invalid option.");
            }
        }
    }
}
