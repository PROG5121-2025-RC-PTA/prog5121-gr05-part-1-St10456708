package com.mycompany.mavenproject4;

public class Login {

    private String username;
    private String password;
    private String phoneNumber;
    private String firstName;
    private String lastName;
    private boolean isLoggedIn;

    public Login(String username, String password, String phoneNumber, String firstName, String lastName) {
        this.username = username;
        this.password = password;
        this.phoneNumber = phoneNumber;
        this.firstName = firstName;
        this.lastName = lastName;
        this.isLoggedIn = false;
    }

    public boolean checkUserName() {
        return username.contains("_") && username.length() <= 5;
    }

    public boolean checkPasswordComplexity() {
        return password.length() >= 8
                && password.matches(".*[A-Z].*")
                && password.matches(".*\\d.*")
                && password.matches(".*[!@#$%^&*()].*");
    }

    public boolean checkCellPhoneNumber() {
        return phoneNumber.matches("^\\+27[6-8][0-9]{8}$");
    }

    public boolean loginUser(String enteredUsername, String enteredPassword) {
        if (enteredUsername.equals(this.username) && enteredPassword.equals(this.password)) {
            this.isLoggedIn = true;
            return true;
        }
        return false;
    }

    public String returnLoginStatus() {
        if (this.isLoggedIn) {
            return "Welcome " + firstName + ", " + lastName + " it is great to see you again.";
        }
        return "Username or password incorrect, please try again.";
    }
}
