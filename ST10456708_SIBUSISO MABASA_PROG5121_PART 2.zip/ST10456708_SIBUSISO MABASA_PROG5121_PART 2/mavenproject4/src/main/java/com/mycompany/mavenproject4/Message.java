package com.mycompany.mavenproject4;

import org.json.JSONObject;
import java.io.FileWriter;
import java.io.IOException;

public class Message {

    private String messageId;
    private static int messageCount = 0;
    private int messageNumber;
    private String recipient;
    private String messageText;
    private String messageHash;

    public Message(String recipient, String messageText) {
        this.messageId = generateMessageID();
        this.recipient = recipient;
        this.messageText = messageText;
        this.messageNumber = ++messageCount;
        this.messageHash = createMessageHash();
    }

    private String generateMessageID() {
        long number = (long) (Math.random() * 1_000_000_0000L);
        return String.format("%010d", number);
    }

    public boolean checkMessageID() {
        return messageId.length() == 10;
    }

    public boolean checkRecipientCell() {
        return recipient.matches("^\\+27[6-8][0-9]{8}$");
    }

    public String createMessageHash() {
        String[] words = messageText.trim().split("\\s+");
        String first = words.length > 0 ? words[0].toUpperCase() : "FIRST";
        String last = words.length > 1 ? words[words.length - 1].toUpperCase() : first;
        return messageId.substring(0, 2) + ":" + messageNumber + ":" + first + last;
    }

    public String sendMessage(String action) {
        switch (action.toLowerCase()) {
            case "send":
                return "Message successfully sent.";
            case "discard":
                return "Press 0 to delete message.";
            case "store":
                storeMessageToJson();
                return "Message successfully stored.";
            default:
                return "Invalid action.";
        }
    }

    public void storeMessageToJson() {
        try {
            JSONObject obj = new JSONObject();
            obj.put("MessageID", messageId);
            obj.put("MessageHash", messageHash);
            obj.put("Recipient", recipient);
            obj.put("Message", messageText);

            FileWriter file = new FileWriter("storemessage.json", true);
            file.write(obj.toString() + System.lineSeparator());
            file.close();
        } catch (IOException e) {
            System.out.println("Error saving message to JSON: " + e.getMessage());
        }
    }

    public String printMessageDetails() {
        return "MessageID: " + messageId
                + "\nMessage Hash: " + messageHash
                + "\nRecipient: " + recipient
                + "\nMessage: " + messageText;
    }

    public static int returnTotalMessages() {
        return messageCount;
    }
}
