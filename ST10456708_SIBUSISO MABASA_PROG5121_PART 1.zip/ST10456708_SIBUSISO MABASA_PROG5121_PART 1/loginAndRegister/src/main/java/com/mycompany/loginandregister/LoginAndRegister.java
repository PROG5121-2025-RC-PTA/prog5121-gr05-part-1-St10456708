/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.loginandregister;

/**
 *
 * @author RC_Student_lab
 */
public class LoginAndRegister {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
