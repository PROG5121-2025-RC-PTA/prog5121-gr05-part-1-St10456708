package com.mycompany.mavenproject2;

import java.util.regex.*;

public class Login {

    private String username;
    private String password;
    private String phoneNumber;
    private String firstName;
    private String lastName;
    private boolean isLoggedIn;

    // Constructor
    public Login(String username, String password, String phoneNumber, String firstName, String lastName) {
        this.username = username;
        this.password = password;
        this.phoneNumber = phoneNumber;
        this.firstName = firstName;
        this.lastName = lastName;
        this.isLoggedIn = false;
    }

    // 1. Validate username: must contain underscore and be <= 5 characters
    public boolean checkUserName() {
        return username.contains("_") && username.length() <= 5;
    }

    // 2. Validate password complexity
    public boolean checkPasswordComplexity() {
        return password.length() >= 8
      && password.matches(".*[A-Z].*")
      && password.matches(".*\\d.*")
      && password.matches(".*[!@#$%^&*(),.?\":{}|<>].*");
    }

    // 3. Validate cell phone number with regex
    public boolean usernameHasUnderscore(String username) {
     return username.contains("_");
       
  
    }
    // Boolean checkPasswordcomplexity
    public boolean isPasswordComplex(String password) {
    if (password.length() < 8) {
      return false;
    }

    boolean hasUppercase = false;
    boolean hasDigit = false;
    boolean hasSpecialChar = false;

    for (char ch : password.toCharArray()) {
     if (Character.isUpperCase(ch)) {
         hasUppercase = true;
     } else if (Character.isDigit(ch)) {
      hasDigit = true;
     } else if (!Character.isLetterOrDigit(ch)) {
      hasSpecialChar = true;
        }
    }

    return hasUppercase && hasDigit && hasSpecialChar;
}
    //  boolean check cell phone Number validate cell phone number with regex
    public boolean checkcellphoneNunmber(){
    return phoneNumber.matches("^\\+27[6-8][0-9]{8}$");
       
    }
    // String RegisterUser()
    public class UserRegistration {

    public static String registerUser(String username, String password) {
     boolean isUsernameValid = username.contains("_");
     boolean isPasswordValid = isPasswordComplex(password);

     if (!isUsernameValid && !isPasswordValid) {
     return "Username is incorrectly formatted and password does not meet complexity requirements.";
        } else if (!isUsernameValid) {
          return "Username is incorrectly formatted.";
        } else if (!isPasswordValid) {
         return "Password does not meet the complexity requirements.";
        } else {
         return "User registered successfully.";
        }
    }

    private static boolean isPasswordComplex(String password) {
     if (password.length() < 8) return false;

     boolean hasUppercase = false;
     boolean hasDigit = false;
     boolean hasSpecialChar = false;

        for (char ch : password.toCharArray()) {
        if (Character.isUpperCase(ch)) hasUppercase = true;
        else if (Character.isDigit(ch)) hasDigit = true;
            else if (!Character.isLetterOrDigit(ch)) hasSpecialChar = true;
        }

    // 4. Registration method returning correct messages
    public String registerUser() {
        if (!checkUserName()) {
            return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.";
        }
        if (!checkPasswordComplexity()) {
            return "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        }
        if (checkCellPhoneNumber()) {
            return "Cell phone number incorrectly formatted or does not contain international code.";
        }
        return "User successfully registered.";
    }

    // 5. Login method checks stored credentials
    public boolean loginUser(String enteredUsername, String enteredPassword) {
        if (enteredUsername.equals(this.username) && enteredPassword.equals(this.password)) {
            this.isLoggedIn = true;
            return true;
        }
        return false;
    }

    // 6. Return login status message
    public String returnLoginStatus() {
        if (this.isLoggedIn) {
            return "Welcome " + firstName + ", " + lastName + " it is great to see you again.";
        }
        return "Username or password incorrect, please try again.";
    }
}
