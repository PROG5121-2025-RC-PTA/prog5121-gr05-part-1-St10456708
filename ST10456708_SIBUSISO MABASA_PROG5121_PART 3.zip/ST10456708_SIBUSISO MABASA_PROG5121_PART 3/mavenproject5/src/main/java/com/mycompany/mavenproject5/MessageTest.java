
import com.mycompany.mavenproject5.Message;


public class MessageTest {

    public static void main(String[] args) {
        // Load existing stored messages
        Message.loadStoredMessagesFromJson();

        // Sample Test Data
        Message m1 = new Message("+27834557896", "Did you get the cake?");
        System.out.println(m1.sentMessage("send"));

        Message m2 = new Message("+27838884567", "Where are you? You are late! I have asked you to be on time.");
        System.out.println(m2.sentMessage("store"));

        Message m3 = new Message("+27834484567", "Yohoooo, I am at your gate.");
        System.out.println(m3.sentMessage("disregard"));

        Message m4 = new Message("0838884567", "It is dinner time !");
        System.out.println(m4.sentMessage("send"));

        Message m5 = new Message("+27838884567", "Ok, I am leaving without you.");
        System.out.println(m5.sentMessage("store"));

        System.out.println("\n--- Senders and Recipients ---");
        Message.displayAllSendersAndRecipients();

        System.out.println("\n--- Longest Message ---");
        Message.displayLongestSentMessage();

        System.out.println("\n--- Search by ID ---");
        Message.searchByMessageId(m1.messageId);

        System.out.println("\n--- Search by Recipient ---");
        Message.searchByRecipient("+27838884567");

        System.out.println("\n--- Delete by Hash ---");
        Message.deleteByMessageHash(m1.createMessageHash());

        System.out.println("\n--- Final Report ---");
        Message.displayFullReport();
    }
}
