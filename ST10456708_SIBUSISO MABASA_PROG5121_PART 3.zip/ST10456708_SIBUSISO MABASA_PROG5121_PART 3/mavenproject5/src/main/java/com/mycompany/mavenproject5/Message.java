package com.mycompany.mavenproject5;

import org.json.JSONObject;
import org.json.JSONArray;
import org.json.JSONException;

import java.io.*;
import java.util.*;

public class Message {

    public String messageId;
    private static int messageCount = 0;
    private int messageNumber;
    private String recipient;
    private String messageText;
    private String messageHash;

    // Static arrays (lists)
    public static ArrayList<Message> sentMessages = new ArrayList<>();
    public static ArrayList<Message> disregardedMessages = new ArrayList<>();
    public static ArrayList<Message> storedMessages = new ArrayList<>();
    public static ArrayList<String> messageHashes = new ArrayList<>();
    public static ArrayList<String> messageIds = new ArrayList<>();

    public Message(String recipient, String messageText) {
        this.messageId = generateMessageId();
        this.recipient = recipient;
        this.messageText = messageText;
        this.messageNumber = ++messageCount;
        this.messageHash = createMessageHash();
    }

    private String generateMessageId() {
        long number = (long) (Math.random() * 1_000_000_0000L);
        return String.format("%010d", number);
    }

    public boolean checkMessageID() {
        return messageId.length() == 10;
    }

    public boolean checkRecipientCell() {
        return recipient.matches("\\+\\d{10,13}");
    }

    public String createMessageHash() {
        String[] words = messageText.trim().split("\\s+");
        String first = words[0].toUpperCase();
        String last = words[words.length - 1].toUpperCase();
        return messageId.substring(0, 2) + "i" + messageNumber + "i" + first + last;
    }

    public String sentMessage(String action) {
        switch (action.toLowerCase()) {
            case "send":
                sentMessages.add(this);
                messageHashes.add(messageHash);
                messageIds.add(messageId);
                return "Message successfully sent.";
            case "store":
                storedMessages.add(this);
                messageHashes.add(messageHash);
                messageIds.add(messageId);
                storeMessageToJson();
                return "Message successfully stored.";
            case "disregard":
                disregardedMessages.add(this);
                return "Message disregarded.";
            default:
                return "Invalid action";
        }
    }

    public void storeMessageToJson() {
        try {
            JSONObject obj = new JSONObject();
            obj.put("MessageID", messageId);
            obj.put("MessageHash", messageHash);
            obj.put("Recipient", recipient);
            obj.put("Message", messageText);

            FileWriter file = new FileWriter("storedMessages.json", true);
            file.write(obj.toString() + System.lineSeparator());
            file.close();
        } catch (IOException e) {
            System.out.println("Error saving message to JSON: " + e.getMessage());
        }
    }

    public static void loadStoredMessagesFromJson() {
        try {
            BufferedReader reader = new BufferedReader(new FileReader("storedMessages.json"));
            String line;
            while ((line = reader.readLine()) != null) {
                JSONObject obj = new JSONObject(line);
                Message msg = new Message(
                        obj.getString("Recipient"),
                        obj.getString("Message")
                );
                msg.messageId = obj.getString("MessageID");
                msg.messageHash = obj.getString("MessageHash");
                storedMessages.add(msg);
                messageHashes.add(msg.messageHash);
                messageIds.add(msg.messageId);
            }
            reader.close();
        } catch (IOException | JSONException e) {
            System.out.println("Error loading stored messages: " + e.getMessage());
        }
    }

    public static void displayAllSendersAndRecipients() {
        for (Message msg : sentMessages) {
            System.out.println("Sender: System | Recipient: " + msg.recipient);
        }
    }

    public static void displayLongestSentMessage() {
        Message longest = null;
        for (Message msg : sentMessages) {
            if (longest == null || msg.messageText.length() > longest.messageText.length()) {
                longest = msg;
            }
        }
        if (longest != null) {
            System.out.println("Longest Sent Message:\n" + longest.printMessageDetails());
        } else {
            System.out.println("No sent messages.");
        }
    }

    public static void searchByMessageId(String id) {
        for (Message msg : sentMessages) {
            if (msg.messageId.equals(id)) {
                System.out.println("Message found:\nRecipient: " + msg.recipient + "\nMessage: " + msg.messageText);
                return;
            }
        }
        System.out.println("Message ID not found.");
    }

    public static void searchByRecipient(String number) {
        boolean found = false;
        for (Message msg : sentMessages) {
            if (msg.recipient.equals(number)) {
                System.out.println(msg.printMessageDetails());
                found = true;
            }
        }
        if (!found) {
            System.out.println("No messages found for recipient: " + number);
        }
    }

    public static void deleteByMessageHash(String hash) {
        Iterator<Message> iterator = sentMessages.iterator();
        while (iterator.hasNext()) {
            Message msg = iterator.next();
            if (msg.messageHash.equals(hash)) {
                iterator.remove();
                messageHashes.remove(hash);
                messageIds.remove(msg.messageId);
                System.out.println("Message deleted.");
                return;
            }
        }
        System.out.println("Message hash not found.");
    }

    public static void displayFullReport() {
        if (sentMessages.isEmpty()) {
            System.out.println("No sent messages.");
            return;
        }
        for (Message msg : sentMessages) {
            System.out.println("------------");
            System.out.println(msg.printMessageDetails());
        }
    }

    public String printMessageDetails() {
        return "MessageID: " + messageId
                + "\nMessage Hash: " + messageHash
                + "\nRecipient: " + recipient
                + "\nMessage: " + messageText;
    }

    public static int returnTotalMessages() {
        return messageCount;
    }
}
